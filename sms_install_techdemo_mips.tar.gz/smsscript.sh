# This is an example how to use an eventhandler with smsd.
# $1 is the type of the event wich can be SENT, RECEIVED, FAILED or REPORT.
# $2 is the filename of the sms.
# $3 is the message id. Only used for SENT messages with status report.

# Die SMS muss folgende Syntax aufweisen:
# Passwort BEFEHL
# z.B. t3st REBOOT

# Hier das Passwort festlegen
PASSWORD="t3st"


if [ "$1" = "RECEIVED" ]; then
       TEXT=`sed -e '1,/^$/ d' < $2`
       # Make text uppercase:
       RCVPASS=`echo "$TEXT" | cut -d" " -f1`
       ACTION=`echo "$TEXT" | cut -d" " -f2`
       if [ "$PASSWORD" = "$RCVPASS" ]; then
               case $ACTION in
                       #Reboot Router
                       REBOOT)
	                        echo `date`: REBOOT-SMS empfangen >> /var/log/sms.log
				logger "REBOOT-SMS empfangen, Geraet wird neu gestartet"
				reboot
                      ;;
                       #Shutdown Router
                       SHUTDOWN)
                               shutdown -h now
                       ;;
                       #Reconnect WAN
                       RECONNECTWAN)
			       echo `date`: RECONNECT-SMS empfangen, WAN wird neu gestartet >> /var/log/sms.log
		               logger "RECONNECT-SMS empfangen, Schnittstelle WAN wird neu gestartet"
                               ifup wan
                       ;;
                       #Reconnect WWAN
                       RECONNECTWWAN)
                               echo `date`: RECONNECT-SMS empfangen, WWAN wird neu gestartet >> /var/log/sms.log
                               logger "RECONNECT-SMS empfangen, Schnittstelle WWAN wird neu gestartet"
                               ifup wan
                       ;;
                       #Befehl
                       BEFEHL1)
                               command
                       ;;
               esac
       else
	 echo `date`: SMS empfangen: $TEXT >> /var/log/sms.log
	 logger "SMS empfangen: $TEXT"
	fi
fi


